#!python
import sys

sys.stdout.write('Hello from weather script!')

